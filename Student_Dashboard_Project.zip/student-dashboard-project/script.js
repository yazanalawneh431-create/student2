// -------------------- DATA AND LOCAL STORAGE --------------------
const STORAGE_KEYS = {
  courses: "studentSpace_courses",
  assignments: "studentSpace_assignments",
  student: "studentSpace_student"
};

const defaultStudent = {
  fullName: "Yazan Ameen Alawneh",
  dateOfBirth: "",
  major: "Computer Engineering",
  nationality: "Jordanian"
};

let courses = loadData(STORAGE_KEYS.courses, []);
let assignments = loadData(STORAGE_KEYS.assignments, []);
let student = loadData(STORAGE_KEYS.student, defaultStudent);

function loadData(key, fallback) {
  try {
    const saved = localStorage.getItem(key);
    return saved ? JSON.parse(saved) : fallback;
  } catch (error) {
    console.error("Could not read saved data:", error);
    return fallback;
  }
}

function saveData() {
  localStorage.setItem(STORAGE_KEYS.courses, JSON.stringify(courses));
  localStorage.setItem(STORAGE_KEYS.assignments, JSON.stringify(assignments));
  localStorage.setItem(STORAGE_KEYS.student, JSON.stringify(student));
}

// Add sample data only on the first visit, to make the dashboard easy to preview.
if (localStorage.getItem(STORAGE_KEYS.courses) === null &&
    localStorage.getItem(STORAGE_KEYS.assignments) === null) {
  courses = [
    { id: makeId(), name: "Web Development", credits: 3, startDate: "2026-09-01", endDate: "2027-01-15", instructor: "Dr. Ahmad", classroom: "Lab 204", status: "In Progress" },
    { id: makeId(), name: "Data Structures", credits: 3, startDate: "2026-02-01", endDate: "2026-06-15", instructor: "Dr. Sara", classroom: "Room 105", status: "Completed" },
    { id: makeId(), name: "Computer Networks", credits: 3, startDate: "2026-09-01", endDate: "2027-01-15", instructor: "Dr. Khaled", classroom: "Room 310", status: "In Progress" }
  ];
  assignments = [
    { id: makeId(), title: "HTML & CSS Project", courseId: courses[0].id, deadline: "2026-11-25", status: "Doing" },
    { id: makeId(), title: "Network Research", courseId: courses[2].id, deadline: "2026-12-02", status: "To Do" },
    { id: makeId(), title: "Data Structures Report", courseId: courses[1].id, deadline: "2026-10-20", status: "Done" }
  ];
  saveData();
}

function makeId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[char]);
}

function initials(name) {
  return name.trim().split(/\s+/).slice(0, 2).map(part => part[0]).join("").toUpperCase();
}

function formatDate(value) {
  if (!value) return "—";
  return new Date(value + "T00:00:00").toLocaleDateString("en-US", {
    month: "short", day: "numeric", year: "numeric"
  });
}

function showToast(message) {
  const toast = document.getElementById("toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.remove("show"), 2600);
}

// -------------------- NAVIGATION --------------------
const sections = ["dashboard", "courses", "assignments", "student"];

function showSection(sectionName) {
  sections.forEach(name => {
    document.getElementById(name + "Section").classList.toggle("active", name === sectionName);
    document.querySelector(`[data-section="${name}"]`).classList.toggle("active", name === sectionName);
  });
  document.getElementById("pageName").textContent =
    sectionName === "student" ? "Student Info" : sectionName[0].toUpperCase() + sectionName.slice(1);
  document.getElementById("sidebar").classList.remove("open");
  if (sectionName === "dashboard") renderDashboard();
  if (sectionName === "courses") renderCourses();
  if (sectionName === "assignments") renderAssignments();
}

document.querySelectorAll(".nav-link").forEach(button => {
  button.addEventListener("click", () => showSection(button.dataset.section));
});
document.querySelectorAll("[data-go]").forEach(button => {
  button.addEventListener("click", () => showSection(button.dataset.go));
});
document.getElementById("menuButton").addEventListener("click", () => {
  document.getElementById("sidebar").classList.toggle("open");
});

// -------------------- DASHBOARD --------------------
function renderDashboard() {
  document.getElementById("totalCourses").textContent = courses.length;
  document.getElementById("completedCourses").textContent = courses.filter(c => c.status === "Completed").length;
  document.getElementById("progressCourses").textContent = courses.filter(c => c.status === "In Progress").length;
  document.getElementById("droppedCourses").textContent = courses.filter(c => c.status === "Dropped").length;

  const recent = document.getElementById("recentCourses");
  recent.innerHTML = courses.slice(0, 4).map(course => `
    <div class="recent-item">
      <div class="item-main"><div class="course-symbol">${escapeHTML(course.name.charAt(0).toUpperCase())}</div>
        <div><strong>${escapeHTML(course.name)}</strong><small>${course.credits} credit hours · ${escapeHTML(course.instructor)}</small></div>
      </div>
      <span class="status ${statusClass(course.status)}">${escapeHTML(course.status)}</span>
    </div>`).join("") || '<div class="empty-state">No courses added yet.</div>';

  const upcoming = assignments.filter(a => a.status !== "Done")
    .sort((a, b) => a.deadline.localeCompare(b.deadline)).slice(0, 4);
  document.getElementById("upcomingAssignments").innerHTML = upcoming.map(task => {
    const course = courses.find(c => c.id === task.courseId);
    return `<div class="upcoming-item">
      <div class="item-main"><div class="course-symbol">✓</div>
        <div><strong>${escapeHTML(task.title)}</strong><small>${escapeHTML(course?.name || "Course unavailable")}</small></div>
      </div>
      <span class="deadline ${isSoon(task.deadline) ? "soon" : ""}">${formatDate(task.deadline)}</span>
    </div>`;
  }).join("") || '<div class="empty-state">You have no pending assignments. Great work!</div>';
}

function isSoon(date) {
  const days = (new Date(date + "T00:00:00") - new Date(new Date().toDateString())) / 86400000;
  return days >= 0 && days <= 7;
}

function statusClass(status) {
  return "status-" + status.toLowerCase().replace(/\s+/g, "-");
}

// -------------------- COURSES: CREATE, READ, UPDATE, DELETE --------------------
const courseDialog = document.getElementById("courseDialog");
const courseForm = document.getElementById("courseForm");

document.getElementById("addCourseButton").addEventListener("click", () => openCourseDialog());
function openCourseDialog(course = null) {
  courseForm.reset();
  document.getElementById("courseId").value = course?.id || "";
  document.getElementById("courseDialogTitle").textContent = course ? "Edit Course" : "Add New Course";
  if (course) {
    document.getElementById("courseName").value = course.name;
    document.getElementById("creditHours").value = course.credits;
    document.getElementById("startDate").value = course.startDate;
    document.getElementById("endDate").value = course.endDate;
    document.getElementById("instructorName").value = course.instructor;
    document.getElementById("classroom").value = course.classroom;
    document.getElementById("courseStatus").value = course.status;
  }
  courseDialog.showModal();
}

courseForm.addEventListener("submit", event => {
  event.preventDefault();
  const id = document.getElementById("courseId").value;
  const startDate = document.getElementById("startDate").value;
  const endDate = document.getElementById("endDate").value;
  if (endDate < startDate) {
    showToast("End date must be after the start date.");
    return;
  }
  const course = {
    id: id || makeId(),
    name: document.getElementById("courseName").value.trim(),
    credits: Number(document.getElementById("creditHours").value),
    startDate,
    endDate,
    instructor: document.getElementById("instructorName").value.trim(),
    classroom: document.getElementById("classroom").value.trim(),
    status: document.getElementById("courseStatus").value
  };
  if (id) {
    courses = courses.map(item => item.id === id ? course : item);
    showToast("Course updated successfully.");
  } else {
    courses.push(course);
    showToast("New course added successfully.");
  }
  saveData();
  courseDialog.close();
  refreshAll();
});

function renderCourses() {
  const search = document.getElementById("courseSearch").value.toLowerCase();
  const filter = document.getElementById("courseFilter").value;
  const filtered = courses.filter(course =>
    (filter === "All" || course.status === filter) &&
    (course.name.toLowerCase().includes(search) || course.instructor.toLowerCase().includes(search))
  );
  document.getElementById("coursesTable").innerHTML = filtered.map(course => `
    <tr>
      <td><div class="table-course"><div class="course-symbol">${escapeHTML(course.name.charAt(0).toUpperCase())}</div><div><strong>${escapeHTML(course.name)}</strong><span class="table-sub">${escapeHTML(course.classroom)}</span></div></div></td>
      <td>${course.credits} hours</td><td>${escapeHTML(course.instructor)}</td>
      <td>${formatDate(course.startDate)}<span class="table-sub">to ${formatDate(course.endDate)}</span></td>
      <td><span class="status ${statusClass(course.status)}">${escapeHTML(course.status)}</span></td>
      <td><div class="actions"><button class="icon-button" title="Edit" data-edit-course="${course.id}">✎</button><button class="icon-button delete-button" title="Delete" data-delete-course="${course.id}">×</button></div></td>
    </tr>`).join("");
  document.getElementById("coursesEmpty").classList.toggle("hidden", filtered.length > 0);
  document.getElementById("coursesTable").querySelectorAll("[data-edit-course]").forEach(button =>
    button.addEventListener("click", () => openCourseDialog(courses.find(c => c.id === button.dataset.editCourse))));
  document.getElementById("coursesTable").querySelectorAll("[data-delete-course]").forEach(button =>
    button.addEventListener("click", () => deleteCourse(button.dataset.deleteCourse)));
}

function deleteCourse(id) {
  const course = courses.find(item => item.id === id);
  if (!course || !confirm(`Delete "${course.name}"? Related assignments will also be deleted.`)) return;
  courses = courses.filter(item => item.id !== id);
  assignments = assignments.filter(item => item.courseId !== id);
  saveData();
  refreshAll();
  showToast("Course deleted.");
}

document.getElementById("courseSearch").addEventListener("input", renderCourses);
document.getElementById("courseFilter").addEventListener("change", renderCourses);

// -------------------- ASSIGNMENTS: CREATE, READ, UPDATE, DELETE --------------------
const assignmentDialog = document.getElementById("assignmentDialog");
const assignmentForm = document.getElementById("assignmentForm");
document.getElementById("addAssignmentButton").addEventListener("click", () => openAssignmentDialog());

function updateCourseOptions(selectedId = "") {
  const select = document.getElementById("assignmentCourse");
  select.innerHTML = courses.length
    ? courses.map(course => `<option value="${course.id}">${escapeHTML(course.name)}</option>`).join("")
    : '<option value="">Add a course first</option>';
  if (selectedId) select.value = selectedId;
}

function openAssignmentDialog(assignment = null) {
  if (!courses.length) {
    showToast("Please add a course before creating an assignment.");
    showSection("courses");
    return;
  }
  assignmentForm.reset();
  updateCourseOptions(assignment?.courseId || "");
  document.getElementById("assignmentId").value = assignment?.id || "";
  document.getElementById("assignmentDialogTitle").textContent = assignment ? "Edit Assignment" : "Add Assignment";
  if (assignment) {
    document.getElementById("assignmentTitle").value = assignment.title;
    document.getElementById("assignmentDeadline").value = assignment.deadline;
    document.getElementById("assignmentStatus").value = assignment.status;
  }
  assignmentDialog.showModal();
}

assignmentForm.addEventListener("submit", event => {
  event.preventDefault();
  const id = document.getElementById("assignmentId").value;
  const assignment = {
    id: id || makeId(),
    title: document.getElementById("assignmentTitle").value.trim(),
    courseId: document.getElementById("assignmentCourse").value,
    deadline: document.getElementById("assignmentDeadline").value,
    status: document.getElementById("assignmentStatus").value
  };
  if (id) {
    assignments = assignments.map(item => item.id === id ? assignment : item);
    showToast("Assignment updated.");
  } else {
    assignments.push(assignment);
    showToast("Assignment added.");
  }
  saveData();
  assignmentDialog.close();
  refreshAll();
});

function renderAssignments() {
  const search = document.getElementById("assignmentSearch").value.toLowerCase();
  const filter = document.getElementById("assignmentFilter").value;
  const filtered = assignments.filter(task => {
    const courseName = courses.find(c => c.id === task.courseId)?.name || "";
    return (filter === "All" || task.status === filter) &&
      (task.title.toLowerCase().includes(search) || courseName.toLowerCase().includes(search));
  }).sort((a, b) => a.deadline.localeCompare(b.deadline));

  document.getElementById("assignmentsTable").innerHTML = filtered.map(task => {
    const course = courses.find(c => c.id === task.courseId);
    const overdue = task.status !== "Done" && task.deadline < new Date().toISOString().slice(0, 10);
    return `<tr>
      <td><strong>${escapeHTML(task.title)}</strong>${overdue ? '<span class="table-sub" style="color:#d88942">Overdue</span>' : ""}</td>
      <td>${escapeHTML(course?.name || "Course unavailable")}</td>
      <td>${formatDate(task.deadline)}</td>
      <td><select class="inline-status" data-status-assignment="${task.id}" aria-label="Change assignment status" style="border:1px solid #eee;border-radius:7px;padding:6px;font:10px Inter;color:#555">
        ${["To Do", "Doing", "Done"].map(status => `<option ${task.status === status ? "selected" : ""}>${status}</option>`).join("")}
      </select></td>
      <td><div class="actions"><button class="icon-button" title="Edit" data-edit-assignment="${task.id}">✎</button><button class="icon-button delete-button" title="Delete" data-delete-assignment="${task.id}">×</button></div></td>
    </tr>`;
  }).join("");
  document.getElementById("assignmentsEmpty").classList.toggle("hidden", filtered.length > 0);

  document.querySelectorAll("[data-status-assignment]").forEach(select => {
    select.addEventListener("change", () => {
      const task = assignments.find(item => item.id === select.dataset.statusAssignment);
      if (task) task.status = select.value;
      saveData();
      refreshAll();
      showToast("Assignment status updated.");
    });
  });
  document.querySelectorAll("[data-edit-assignment]").forEach(button =>
    button.addEventListener("click", () => openAssignmentDialog(assignments.find(a => a.id === button.dataset.editAssignment))));
  document.querySelectorAll("[data-delete-assignment]").forEach(button =>
    button.addEventListener("click", () => deleteAssignment(button.dataset.deleteAssignment)));
}

function deleteAssignment(id) {
  const task = assignments.find(item => item.id === id);
  if (!task || !confirm(`Delete "${task.title}"?`)) return;
  assignments = assignments.filter(item => item.id !== id);
  saveData();
  refreshAll();
  showToast("Assignment deleted.");
}

document.getElementById("assignmentSearch").addEventListener("input", renderAssignments);
document.getElementById("assignmentFilter").addEventListener("change", renderAssignments);

// -------------------- STUDENT INFORMATION --------------------
function renderStudent() {
  const name = student.fullName || "Student";
  const shortName = name.split(" ")[0];
  document.getElementById("welcomeName").textContent = shortName;
  document.getElementById("sidebarName").textContent = name;
  ["topAvatar", "sidebarAvatar", "profileAvatar"].forEach(id => {
    document.getElementById(id).textContent = initials(name);
  });
  document.getElementById("profileName").textContent = name;
  document.getElementById("infoName").textContent = name;
  document.getElementById("infoDob").textContent = formatDate(student.dateOfBirth);
  document.getElementById("infoMajor").textContent = student.major;
  document.getElementById("infoNationality").textContent = student.nationality;
}

const studentDialog = document.getElementById("studentDialog");
document.getElementById("editStudentButton").addEventListener("click", () => {
  document.getElementById("studentName").value = student.fullName;
  document.getElementById("studentDob").value = student.dateOfBirth;
  document.getElementById("studentMajor").value = student.major;
  document.getElementById("studentNationality").value = student.nationality;
  studentDialog.showModal();
});

document.getElementById("studentForm").addEventListener("submit", event => {
  event.preventDefault();
  student = {
    fullName: document.getElementById("studentName").value.trim(),
    dateOfBirth: document.getElementById("studentDob").value,
    major: document.getElementById("studentMajor").value.trim(),
    nationality: document.getElementById("studentNationality").value.trim()
  };
  saveData();
  renderStudent();
  studentDialog.close();
  showToast("Student information saved.");
});

// -------------------- GENERAL HELPERS AND INITIAL RENDER --------------------
document.querySelectorAll("[data-close]").forEach(button => {
  button.addEventListener("click", () => document.getElementById(button.dataset.close).close());
});

function refreshAll() {
  renderDashboard();
  renderCourses();
  renderAssignments();
  renderStudent();
}

document.getElementById("todayLabel").textContent = new Date().toLocaleDateString("en-US", {
  weekday: "short", month: "short", day: "numeric"
});
document.getElementById("year").textContent = new Date().getFullYear();
renderStudent();
refreshAll();
