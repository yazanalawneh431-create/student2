# StudentSpace — Student Dashboard Web App

## Run the project
1. Extract the ZIP file.
2. Open the `student-dashboard-project` folder in Visual Studio Code.
3. Open `index.html` in a browser, or use the VS Code Live Server extension.
4. The app opens directly on the Dashboard. No login is required.

## Files
- `index.html`: page structure, navigation, tables, and forms.
- `style.css`: layout, colors, responsive design, and mobile menu.
- `script.js`: JavaScript data, CRUD operations, validation, and localStorage.

## Implemented requirements
- Dashboard statistics: total, completed, in-progress, and dropped courses.
- Sidebar navigation with active-section highlighting.
- Course create, read, update, delete, search, and status filtering.
- Assignment create, read, update, delete, inline status updates, search, and filtering.
- Student information display and editing.
- localStorage persistence after refreshing the browser.
- Dynamic dashboard and upcoming/overdue assignment display.
- Responsive layout for desktop, tablet, and mobile.

## Storage
The browser stores data using these localStorage keys:
- `studentSpace_courses`
- `studentSpace_assignments`
- `studentSpace_student`

To reset the demo data, open browser DevTools → Application/Storage → Local Storage and remove these keys.
